#include <leveldb/c.h>
#include <string.h>
#include <stdlib.h>
#include <nan.h>

using v8::Exception;
using v8::FunctionCallbackInfo;
using v8::Isolate;
using v8::Local;
using v8::Number;
using v8::Object;
using v8::String;
using v8::Value;
using v8::Array;

namespace addon {
  leveldb_t *db;

  const char* ToCString(const Nan::Utf8String& value) {
    return *value ? *value : "string conversion failed";
  }

  void Open(const Nan::FunctionCallbackInfo<v8::Value>& info) {

    if (info.Length() != 1) {
      Nan::ThrowTypeError("Wrong number of arguments");
      return;
    }

    if (!info[0]->IsString()) {
      Nan::ThrowTypeError("Wrong type of arguments");
      return;
    }

    Nan::Utf8String str(info[0]);
    const char* arg = ToCString(str);

    if(strlen(arg) == 0) {
      Nan::ThrowError("Database name is empty");
      return;
    } else {
      leveldb_options_t *options;
      options = leveldb_options_create();
      leveldb_options_set_create_if_missing(options, 1);

      leveldb_options_set_compression(options, 2);

      char *err = NULL;
      db = leveldb_open(options, arg, &err);

      if (err != NULL) {
        Nan::ThrowError("Failed to open database");
        return;
      }
      leveldb_free(err); err = NULL;

      leveldb_options_destroy(options);
      info.GetReturnValue().Set(Nan::New("opened").ToLocalChecked());
    }
  }

  void Close(const Nan::FunctionCallbackInfo<v8::Value>& info) {
    leveldb_close(db);
    info.GetReturnValue().Set(Nan::New("closed").ToLocalChecked());
  }

  void Get(const Nan::FunctionCallbackInfo<v8::Value>& info) {

    if (info.Length() != 1) {
     Nan::ThrowTypeError("Wrong number of arguments");
     return;
    }

    if (!info[0]->IsString()) {
     Nan::ThrowTypeError("Wrong arguments");
     return;
    }

    Nan::Utf8String str(info[0]);
    const char* arg = ToCString(str);

    leveldb_readoptions_t *roptions;
    roptions = leveldb_readoptions_create();

    char *read;
    size_t read_len;
    char *err = NULL;
    read = leveldb_get(db, roptions, arg, str.length(), &read_len, &err);

    if (err != NULL) {
      Nan::ThrowError("Read fail");
      return;
    }
    leveldb_free(err); err = NULL;

    leveldb_readoptions_destroy(roptions);
    info.GetReturnValue().Set(Nan::New(read,read_len).ToLocalChecked());
  }

  // GetKeys: iterate all keys with an optional prefix filter.
  // Usage: getKeys()         -> returns all keys
  //        getKeys("player") -> returns keys starting with "player"
  void GetKeys(const Nan::FunctionCallbackInfo<v8::Value>& info) {
    char* prefix_copy = NULL;
    size_t prefix_len = 0;

    if (info.Length() >= 1 && info[0]->IsString()) {
      Nan::Utf8String str(info[0]);
      const char* arg = ToCString(str);
      prefix_len = str.length();
      // Make a copy so it survives the Utf8String scope
      prefix_copy = (char*)malloc(prefix_len + 1);
      memcpy(prefix_copy, arg, prefix_len);
      prefix_copy[prefix_len] = '\0';
    }

    leveldb_readoptions_t *roptions = leveldb_readoptions_create();
    leveldb_iterator_t *iter = leveldb_create_iterator(db, roptions);

    v8::Local<v8::Array> result = Nan::New<v8::Array>();
    uint32_t idx = 0;

    if (prefix_copy != NULL && prefix_len > 0) {
      leveldb_iter_seek(iter, prefix_copy, prefix_len);
    } else {
      leveldb_iter_seek_to_first(iter);
    }

    while (leveldb_iter_valid(iter)) {
      size_t key_len;
      const char* key = leveldb_iter_key(iter, &key_len);

      // If prefix specified, stop when key no longer matches prefix
      if (prefix_copy != NULL && prefix_len > 0) {
        if (key_len < prefix_len || memcmp(key, prefix_copy, prefix_len) != 0) {
          break;
        }
      }

      Nan::Set(result, idx, Nan::New(key, key_len).ToLocalChecked());
      idx++;

      leveldb_iter_next(iter);
    }

    char* iter_err = NULL;
    leveldb_iter_get_error(iter, &iter_err);
    if (iter_err != NULL) {
      printf("[leveldb-mcpe-native] Iterator error: %s\n", iter_err);
      leveldb_free(iter_err);
    }

    leveldb_iter_destroy(iter);
    leveldb_readoptions_destroy(roptions);
    if (prefix_copy != NULL) free(prefix_copy);

    info.GetReturnValue().Set(result);
  }

  // GetAllEntries: get all key-value pairs where key starts with a prefix.
  // Returns an array of { key: string, value: string } objects.
  void GetAllEntries(const Nan::FunctionCallbackInfo<v8::Value>& info) {
    char* prefix_copy = NULL;
    size_t prefix_len = 0;

    if (info.Length() >= 1 && info[0]->IsString()) {
      Nan::Utf8String str(info[0]);
      const char* arg = ToCString(str);
      prefix_len = str.length();
      prefix_copy = (char*)malloc(prefix_len + 1);
      memcpy(prefix_copy, arg, prefix_len);
      prefix_copy[prefix_len] = '\0';
    }

    leveldb_readoptions_t *roptions = leveldb_readoptions_create();
    leveldb_iterator_t *iter = leveldb_create_iterator(db, roptions);

    v8::Local<v8::Array> result = Nan::New<v8::Array>();
    uint32_t idx = 0;

    if (prefix_copy != NULL && prefix_len > 0) {
      leveldb_iter_seek(iter, prefix_copy, prefix_len);
    } else {
      leveldb_iter_seek_to_first(iter);
    }

    while (leveldb_iter_valid(iter)) {
      size_t key_len, val_len;
      const char* key = leveldb_iter_key(iter, &key_len);
      const char* val = leveldb_iter_value(iter, &val_len);

      // If prefix specified, stop when key no longer matches prefix
      if (prefix_copy != NULL && prefix_len > 0) {
        if (key_len < prefix_len || memcmp(key, prefix_copy, prefix_len) != 0) {
          break;
        }
      }

      v8::Local<v8::Object> obj = Nan::New<v8::Object>();
      Nan::Set(obj, Nan::New("key").ToLocalChecked(), Nan::New(key, key_len).ToLocalChecked());
      Nan::Set(obj, Nan::New("value").ToLocalChecked(), Nan::New(val, val_len).ToLocalChecked());
      Nan::Set(result, idx, obj);
      idx++;

      leveldb_iter_next(iter);
    }

    char* iter_err = NULL;
    leveldb_iter_get_error(iter, &iter_err);
    if (iter_err != NULL) {
      printf("[leveldb-mcpe-native] Iterator error: %s\n", iter_err);
      leveldb_free(iter_err);
    }

    leveldb_iter_destroy(iter);
    leveldb_readoptions_destroy(roptions);
    if (prefix_copy != NULL) free(prefix_copy);

    info.GetReturnValue().Set(result);
  }

  void Put(const Nan::FunctionCallbackInfo<v8::Value>& info) {
    if (info.Length() != 2) {
      Nan::ThrowTypeError("Wrong number of arguments");
      return;
    }

    if (!info[0]->IsString() && !info[1]->IsString()) {
      Nan::ThrowTypeError("Wrong arguments");
      return;
    }

    Nan::Utf8String str(info[0]);
    const char* arg = ToCString(str);

    Nan::Utf8String str2(info[1]);
    const char* arg2 = ToCString(str2);

    leveldb_writeoptions_t *woptions;
    woptions = leveldb_writeoptions_create();
    char *err = NULL;
    leveldb_put(db, woptions, arg, str.length(), arg2, str2.length(), &err);

    if (err != NULL) {
      Nan::ThrowError("Write fail");
      return;
    }
    leveldb_free(err); err = NULL;

    leveldb_writeoptions_destroy(woptions);
    info.GetReturnValue().Set(Nan::New("written").ToLocalChecked());
  }

  void Delete(const Nan::FunctionCallbackInfo<v8::Value>& info) {
    if (info.Length() != 1) {
      Nan::ThrowTypeError("Wrong number of arguments");
      return;
    }

    if (!info[0]->IsString()) {
      Nan::ThrowTypeError("Wrong arguments");
      return;
    }

    Nan::Utf8String str(info[0]);
    const char* arg = ToCString(str);

    leveldb_writeoptions_t *woptions;
    woptions = leveldb_writeoptions_create();
    char *err = NULL;
    leveldb_delete(db, woptions, arg, str.length(), &err);

    if (err != NULL) {
      Nan::ThrowError("Delete fail");
      return;
    }
    leveldb_free(err); err = NULL;

    info.GetReturnValue().Set(Nan::New("deleted").ToLocalChecked());
  }

  void Init(v8::Local<v8::Object> exports) {
    Nan::SetMethod(exports, "open", Open);
    Nan::SetMethod(exports, "close", Close);
    Nan::SetMethod(exports, "get", Get);
    Nan::SetMethod(exports, "getKeys", GetKeys);
    Nan::SetMethod(exports, "getAllEntries", GetAllEntries);
    Nan::SetMethod(exports, "put", Put);
    Nan::SetMethod(exports, "delete", Delete);
  }

  NODE_MODULE(addon, Init)
}
