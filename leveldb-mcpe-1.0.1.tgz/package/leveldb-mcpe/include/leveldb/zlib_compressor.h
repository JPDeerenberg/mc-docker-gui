
#pragma once

#include "leveldb/compressor.h"

namespace leveldb {

	class DLLX ZlibCompressor : public Compressor 
	{
	public:
		static const int SERIALIZE_ID = 2;

		const int compressionLevel;
		const bool raw;
        
        virtual ~ZlibCompressor() {
            
        }

		ZlibCompressor(bool raw = false, int compressionLevel = -1) :
			Compressor(raw ? 4 : 2),
			compressionLevel(compressionLevel),
			raw(raw)
		{
			assert(compressionLevel >= -1 && compressionLevel <= 9);
		}

		virtual void compressImpl(const char* input, size_t length, ::std::string& output) const override;

		virtual bool decompress(const char* input, size_t length, ::std::string &output) const override;

	private:

	};
}