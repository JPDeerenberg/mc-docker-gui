#ifndef NO_ZLIB

#include "leveldb/zlib_compressor.h"

#include <zlib.h>
#include <algorithm>
#include <cmath>

namespace leveldb {

  unsigned long compressBound(unsigned long sourceLen) {
    return(((int)ceil(sourceLen * 1.001)) + 12);
   }

	void ZlibCompressor::compressImpl(const char* input, size_t length, ::std::string& buffer) const
	{
		const size_t BUFSIZE = 128 * 1024;
		unsigned char temp_buffer[BUFSIZE];

		//reserve enough memory to not reallocate on the fly
		buffer.reserve(compressBound(length));

		z_stream strm;
		strm.zalloc = 0;
		strm.zfree = 0;
		strm.next_in = (unsigned char *)(input);
		strm.avail_in = (uint32_t)length;
		strm.next_out = temp_buffer;
		strm.avail_out = BUFSIZE;

		if (raw) {
			deflateInit2(&strm, compressionLevel, Z_DEFLATED, -15, 8, Z_DEFAULT_STRATEGY);
		} else {
			deflateInit(&strm, compressionLevel);
		}

		int deflate_res = Z_OK;
		while (strm.avail_in != 0)
		{
			int res = deflate(&strm, Z_NO_FLUSH);
			assert(res == Z_OK);
			if (strm.avail_out == 0)
			{
				buffer.insert(buffer.end(), temp_buffer, temp_buffer + BUFSIZE);
				strm.next_out = temp_buffer;
				strm.avail_out = BUFSIZE;
			}
		}

		while (deflate_res == Z_OK)
		{
			if (strm.avail_out == 0)
			{
				buffer.insert(buffer.end(), temp_buffer, temp_buffer + BUFSIZE);
				strm.next_out = temp_buffer;
				strm.avail_out = BUFSIZE;
			}
			deflate_res = deflate(&strm, Z_FINISH);
		}

		assert(deflate_res == Z_STREAM_END);
		buffer.insert(buffer.end(), temp_buffer, temp_buffer + BUFSIZE - strm.avail_out);
		deflateEnd(&strm);
	}

	int _zlibInflate(const char* input, size_t length, ::std::string &output, bool raw) {
		const int CHUNK = 64 * 1024;

		int ret;
		size_t have;
		z_stream strm;
		unsigned char out[CHUNK];

		/* allocate inflate state */
		strm.zalloc = Z_NULL;
		strm.zfree = Z_NULL;
		strm.opaque = Z_NULL;
		strm.avail_in = (uint32_t)length;
		strm.next_in = (Bytef*)input;
		
		// Minecraft Bedrock LevelDB uses raw deflate for both ID 2 and ID 4.
		// Therefore, we always try raw deflate (windowBits = -15) first.
		ret = inflateInit2(&strm, -15);
		if (ret != Z_OK)
			return ret;

		bool fellBack = false;

		/* decompress until deflate stream ends or end of file */
		do {
			/* run inflate() on input until output buffer not full */
			do {

				strm.avail_out = CHUNK;
				strm.next_out = out;

				ret = inflate(&strm, Z_NO_FLUSH);
				assert(ret != Z_STREAM_ERROR);  /* state not clobbered */
				
				if (ret == Z_DATA_ERROR && !raw && !fellBack) {
					// Fall back to standard zlib header decompression
					(void)inflateEnd(&strm);
					output.clear();
					
					strm.zalloc = Z_NULL;
					strm.zfree = Z_NULL;
					strm.opaque = Z_NULL;
					strm.avail_in = (uint32_t)length;
					strm.next_in = (Bytef*)input;
					
					ret = inflateInit(&strm);
					if (ret != Z_OK)
						return ret;
					
					fellBack = true;
					break; // break the inner loop to restart with standard inflate
				}

				switch (ret) {
				case Z_NEED_DICT:
					ret = Z_DATA_ERROR;     /* and fall through */
				case Z_DATA_ERROR:
				case Z_MEM_ERROR:
					(void)inflateEnd(&strm);
					return ret;
				}

				have = CHUNK - strm.avail_out;

				output.append((char*)out, have);

			} while (strm.avail_out == 0);

			if (fellBack && strm.avail_in == (uint32_t)length) {
				// If we fell back and reinitialized, continue outer loop
				continue;
			}

			/* done when inflate() says it's done */
		} while (ret != Z_STREAM_END && ret != Z_DATA_ERROR);

		/* clean up and return */
		(void)inflateEnd(&strm);
		return ret == Z_STREAM_END ? Z_OK : Z_DATA_ERROR;
	}

	bool ZlibCompressor::decompress(const char* input, size_t length, ::std::string &output) const {
		return _zlibInflate(input, length, output, raw) == Z_OK;
	}
		
}

#endif